package com.cg.dto;

public class Employee {

	
	int empId;
	String empName;
	int empSal;
	String empAddr;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSal() {
		return empSal;
	}
	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}
	public String getEmpAddr() {
		return empAddr;
	}
	public void setEmpAddr(String empAddr) {
		this.empAddr = empAddr;
	}
	public Employee(int empId, String empName, int empSal, String empAddr) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empAddr = empAddr;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + ", empAddr=" + empAddr + "]";
	}
	public Employee() {
		super();
	}
	public Employee(int empId, int empSal) {
		super();
		this.empId = empId;
		this.empSal = empSal;
	}
	
	
	
}
