package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Employee;

public interface EmployeeDao {

	public Employee addEmployee(Employee emp);
	public Employee getEmployeeById(int empId);
	public ArrayList<Employee> getAllEmployees();
	public int DeleteEmployee(int empId);
	public Employee UpdateEmployee(int empId,int empSal);
}
